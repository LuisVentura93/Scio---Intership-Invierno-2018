$(document).ready(function(){
    alert("Hola mundo");
})